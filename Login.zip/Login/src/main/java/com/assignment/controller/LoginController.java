package com.assignment.controller;

import java.util.List;
import java.util.Optional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.model.Login;
import com.assignment.model.Registration;
import com.assignment.repository.LoginRepository;
import com.assignment.service.LoginService;
import com.assignment.service.RegistrationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/login")

public class LoginController {
	
	@Autowired
	private LoginService loginService;
	
	@Autowired
	private RegistrationService registerService;
	
	@Autowired
	private LoginRepository loginrepo;
	
	@PostMapping("/save")
	public Login saveAll(@RequestBody Login login) {
		return loginService.savedata(login);
	}
	@GetMapping("/findAll")
	public List<Login> getAll(){
		return loginService.get();
	}
	@PutMapping("/update")
	public Login updateAll(@RequestBody Login login) {
		return loginService.savedata(login);
	}
	@DeleteMapping("/delete")
	public void deleteAll() {
		loginService.delete();
	}
	@PostMapping("/auth")
	public ResponseEntity<?> loginData(@RequestBody Registration register, Login log) throws Exception {
	if(register.getEmail()==null || register.getEmail().isBlank()) {
			return ResponseEntity.badRequest().body("email is required");
		}
		if(register.getPassword()==null || register.getPassword().isBlank()) {
			return ResponseEntity.badRequest().body("password is required");
		}
		String response="";
		int status=403;
		
		String email = register.getEmail();
		String password = register.getPassword();
		Registration registerObj = null;
		if(email != null && password != null) {
			registerObj = registerService.fetchByEmailAndPassword(email, password);
			
			
			if(registerObj == null) {
				throw new Exception("Bad Credentials");
					}
			
			
			try {
				Login login = new Login(); // Assuming you need to create a Login object            
				login.setEmail(email);
				login.setPassword(password);
				registerObj =registerService.checkLoginDetails(register.getEmail(), register.getPassword());
				loginService.savedata(login);
				response="login successfull";
				status=200;
				

			}
		catch(Exception e) {
			System.out.println("e");
				response="invalid login details";
		}
			
		
		

	}
	return ResponseEntity.status(status).body(response);	
	
	
        
}
//	@PostMapping("/auth")
//	public ResponseEntity<String>loginUser(@RequestBody Registration login){
//		Optional<Login> existlogin=loginrepo.findByEmail(login.getEmail());
//		if(existlogin.isPresent()&& existlogin.get().getPassword().equals(login.getPassword())) {
//		
//			return ResponseEntity.ok("login successfull");
////			return loginService.savedata(login);
//		}
//		else {
//			return ResponseEntity.status(HttpStatus.UNAUTHORIZED).body("login failed");
//		}
//	}


	
}
