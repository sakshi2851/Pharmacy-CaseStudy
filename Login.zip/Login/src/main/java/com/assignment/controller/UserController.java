package com.assignment.controller;

import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.support.SecurityContextProvider;
import org.springframework.boot.autoconfigure.neo4j.Neo4jProperties.Authentication;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
//import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.model.Login;
import com.assignment.model.Registration;
import com.assignment.model.UserCredential;
import com.assignment.model.UserInfo;
import com.assignment.repository.UserInfoRepository;
import com.assignment.repository.UserRepository;
import com.assignment.service.UserService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/api")
public class UserController {
	
	@Autowired
	private UserService userService;

	private Map<String, Registration>map=new HashMap<String, Registration>();
	
	@Autowired
	private UserInfoRepository userInfo;
	
	@Autowired
	private UserRepository userRepository;
	
	public UserController(UserService userService) {
		super();
		this.userService = userService;
	}
	@PostMapping("/saveinfo")
	public String saveData(@RequestBody UserInfo userInfo) {
		return userService.save(userInfo);
	}
	
	@PostMapping("/savecredential")
	public UserCredential saveCredential(@RequestBody UserCredential userCredential) {
		return userService.create(userCredential);
	}
	@PostMapping("/userdetails")
	public ResponseEntity<?> login(@RequestBody Login login){
		UserCredential userCredential=userService.login(login.getEmail(), login.getPassword());
		if (userCredential==null) {
			return ResponseEntity.status(HttpStatus.UNAUTHORIZED)
					.build().badRequest().body("User not exist");
			
		}
		
		if(!userCredential.getPassword().equals(login.getPassword())) {
			return ResponseEntity.badRequest().body("incorrect password");
		}
		UserInfo userInfo=new UserInfo();
		String role=userInfo.getUserType();
		if("U".equals(role)) {
			return ResponseEntity.ok("Succesful login as user");
		}
		else if("A".equals(role)) {
			return ResponseEntity.ok("Successful login as admin");
			
		}
		else {
			return ResponseEntity.badRequest().body("invalid userRole");
		}
	}
	@GetMapping("/ShowExistingUser")
	public ResponseEntity<List<UserInfo>>showExistingUser(String userType){
		if("U".equals(userType)) {
//			String str=SecurityContextHolder.getContext().getAuthentication().getName();
			UserCredential userCredential= userRepository.findByEmail(userType);
			if(userCredential !=null) {
				UserInfo user =userInfo.findById(userCredential.getId());
				if(user!=null) {
					return ResponseEntity.ok(Collections.singletonList(user));
				}
			}
		}
		else if("A".equals(userType)) {
			List<UserInfo> user=userInfo.findAll();
			return ResponseEntity.ok(user);
		}
		return ResponseEntity.badRequest().body(null);
	}
	@PostMapping("/register")
	public ResponseEntity<?> register(@RequestBody UserInfo userInfo){
		UserInfo userInfo2 = userService.register(userInfo);
		if(userInfo2==null) {
			return ResponseEntity.status(HttpStatus.BAD_REQUEST)
					.build();
		}
		return ResponseEntity.ok().body(userInfo2);
	}
	@PostMapping("/registerUser")
	public ResponseEntity<Registration> createUser(@RequestBody Registration registration){
		if(userService.isEmailAlreadyExists(registration.getEmail())) {
			return new ResponseEntity("email is already exist",HttpStatus.BAD_REQUEST);
			
		}
			userService.registerUser(registration);
			return new ResponseEntity("user registered successfully",HttpStatus.CREATED);
			
		
	}
	@DeleteMapping("/delete")
	public void deleteId(int id) {
		userService.delete(id);
	}
	
	

}
