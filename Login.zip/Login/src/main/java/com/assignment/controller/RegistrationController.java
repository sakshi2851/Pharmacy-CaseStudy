package com.assignment.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.assignment.model.Login;
import com.assignment.model.Registration;
import com.assignment.repository.RegistrationRepository;
import com.assignment.service.RegistrationService;

@CrossOrigin(origins = "*")
@RestController
@RequestMapping("/register")
public class RegistrationController {
	
	@Autowired
	private RegistrationRepository registerrepository;
	
	@Autowired
	private RegistrationService registerservice;
	
	@PostMapping("/create")
	public Registration saveData(@RequestBody Registration register) {
		return registerservice.saveData(register);
		
	}
	@GetMapping("/finddata")
	public List<Registration> getAll(){
		return registerservice.get();
	}
	@PutMapping("/updatedata")
	public Registration updateData(@RequestBody Registration register) {
		return registerservice.updateData(register);
		
	}
	@DeleteMapping("/deletedata")
	public void deleteData() {
		registerservice.delete();
	}

	@PostMapping("/authregister")
	public ResponseEntity<String> Registration(@RequestBody Registration Log) {
		if(Log.getFirstName()==null || Log.getFirstName().isBlank()) {
			return ResponseEntity.badRequest().body("firstname is required");
		}
		if(Log.getLastName()==null || Log.getLastName().isBlank()) {
			return ResponseEntity.badRequest().body("lastname is required");
		}
	    if(Log.getEmail()==null || Log.getEmail().isBlank()) {
	    	return ResponseEntity.badRequest().body("email is required");
	    }
	    if(Log.getPassword()==null || Log.getPassword().isBlank()) {
	    	return ResponseEntity.badRequest().body("password is required");
	    }
	    if(Log.getMobileNumber()==null || Log.getMobileNumber().isBlank()) {
	    	return ResponseEntity.badRequest().body("mobilenumber is required");
	    }
	    if(registerrepository.existsByEmail(Log.getEmail())){
	    	return ResponseEntity.badRequest().body("email already exists");
	    	
	    }
	    
	    registerservice.saveData(Log);
	    return ResponseEntity.ok().body("user registered successfully");
	}


}
