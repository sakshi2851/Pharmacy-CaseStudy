package com.assignment.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.assignment.model.Login;
import com.assignment.model.Registration;
import com.assignment.repository.RegistrationRepository;

@Service
public class RegistrationService {
	
	
	private RegistrationRepository registration;
	
	    
	    public RegistrationService(RegistrationRepository registration) {
	        this.registration = registration; // Initialize the repository
	    }
	public Registration saveData(Registration register) {
		return registration.save(register);
	}
	public List<Registration> get(){
		return registration.findAll();
	}
	public Registration updateData(Registration register) {
		return registration.save(register);
	}
	public void delete() {
		registration.deleteAll();
		
	}
	public Registration fetchByEmailAndPassword(String email, String password) {
		return registration.findByEmailAndPassword(email, password);
	}
	
	public Registration checkLoginDetails(String email,String password)throws Exception{
		if(registration.findAll().parallelStream().noneMatch(p->p.getEmail().equals(email))) {
			System.out.println("registrationRepository"+email);
			throw new Exception("username not exist");
			

		}
		return null;
	}
}