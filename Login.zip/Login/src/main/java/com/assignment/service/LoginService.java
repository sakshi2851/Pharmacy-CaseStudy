package com.assignment.service;

import java.util.List;
import java.util.stream.Collectors;

import org.apache.http.auth.InvalidCredentialsException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.assignment.model.Login;
import com.assignment.repository.LoginRepository;

@Service
public class LoginService {
	
	@Autowired
	private LoginRepository repo;
	
	public Login savedata(Login login) {
		return repo.save(login);
	}

	public List<Login> get(){
		return repo.findAll();
	}
	public void delete() {
		repo.deleteAll();
	}
	public Login update(Login login) {
		return repo.save(login);

}
	public Login checkLoginDetails(String username,String password)throws Exception{
		if(repo.findAll().parallelStream().noneMatch(p->p.getEmail().equals(username))) {
			System.out.println("loginRepository"+username);
			throw new Exception("username not found");
			

	}
		if(repo.findAll().parallelStream().noneMatch(p->p.getPassword().equals(password))) {
			System.out.println("loginRepository"+password);
			throw new Exception("password not found");
		}
		if(repo.findAll().parallelStream().filter(p->p.getEmail().equals(username)).collect(Collectors.toList()).get(0)!=null) {
			System.out.println("wrongRepository"+username);
		}
		
			System.out.println("loginReposiotry"+password);
			return repo.findAll().parallelStream().filter(p->p.getPassword().equals(password)).collect(Collectors.toList()).get(0); 
		}
	public boolean matchesPassword(String password,String encodedPassword) {
		return password.equals(encodedPassword);
	}
	

	}
		
	
