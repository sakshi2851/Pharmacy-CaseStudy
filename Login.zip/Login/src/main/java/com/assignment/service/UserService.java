package com.assignment.service;

import java.util.Iterator;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.assignment.model.Login;
import com.assignment.model.Registration;
import com.assignment.model.UserCredential;
import com.assignment.model.UserInfo;
import com.assignment.repository.LoginRepository;
import com.assignment.repository.RegistrationRepository;
import com.assignment.repository.UserInfoRepository;
import com.assignment.repository.UserRepository;

@Service
public class UserService {
	@Autowired
	private UserRepository userRepository; 
	
	@Autowired
	private  UserInfoRepository userInfoRepository;
	
	@Autowired
	private RegistrationRepository register;
	
	@Autowired
	private LoginRepository loginRepository;
	
	public UserService(UserRepository UserRepository,UserInfoRepository userInfoRepository) {
		this.userRepository=userRepository;
		this.userInfoRepository=userInfoRepository;
	
	}
	public UserCredential login(String email,String password) {
		UserCredential usercredential=userRepository.findByEmail(email);
		if(usercredential==null || !usercredential.getPassword().equals(password)) {
			return null;
		}
		return usercredential;
	}
	public UserInfo register(UserInfo userInfo) {
		UserCredential usercredential= new UserCredential();
		usercredential.setEmail(usercredential.getEmail());
		usercredential.setPassword(usercredential.getPassword());
		userRepository.save(usercredential);
		userInfo.setUserType("U");
		userInfoRepository.save(userInfo);
		return userInfo;
	}
	public String save(UserInfo userInfo) {
		List users=userInfoRepository.findAll();
		boolean isUserExists=false;
		for (Iterator iterator = users.iterator(); iterator.hasNext();) {
			UserInfo user = (UserInfo) iterator.next();
			if(user.getEmail().equals(userInfo.getEmail())) {
				isUserExists=true;
			}
			
		};
		if(isUserExists) {
			return "user already exists";
		}
		userInfoRepository.save(userInfo);
		return "user details saved successfully";
	}
	public UserCredential create(UserCredential userCredential) {
		return userRepository.save(userCredential);
	}
	public boolean isEmailAlreadyExists(String email) {
		return register.existsByEmail(email);
	}
	public void registerUser(Registration registration) {
		Login login=new Login();
		login.setEmail(registration.getEmail());
		loginRepository.save(login);
	}
	public void delete(int id) {
		userInfoRepository.deleteById(id);
	}
	

	
	

}