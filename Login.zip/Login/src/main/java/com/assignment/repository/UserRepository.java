package com.assignment.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.assignment.model.UserCredential;
import com.assignment.model.UserInfo;

@Repository
public interface UserRepository extends JpaRepository<UserCredential, Integer>{

	UserCredential findByEmail(String email);
	
	
}
