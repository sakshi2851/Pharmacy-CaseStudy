package com.assignment.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.stereotype.Service;

import com.assignment.model.Registration;

@Repository
public interface RegistrationRepository extends JpaRepository<Registration, String> {
	boolean existsByEmail(String email);
     Registration findByEmailAndPassword(String email, String password);

}
